Well, what to read:) do not read:) joke:) u must read many IT ebooks and practice...

This simple php script is free! NO license(licence) ... ... ...
Feel free to create own simple counter service:) to change the script, and what u want... :)

With this php script you can create own web counter service like:
http://www.webcounter.com
http://www.hitwebcounter.com
http://www.freecountercode.com/counter-setup.php
http://smallcounter.com
and others...

Good luck!

If u want, u can visit my web page: www.eti.pw
