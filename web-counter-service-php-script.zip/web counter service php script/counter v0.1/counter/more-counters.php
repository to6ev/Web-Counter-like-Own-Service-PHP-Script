<!DOCTYPE html>
<html lang="en">
<head>
<LINK REL="SHORTCUT ICON" href="img/counter.jpeg">
    <meta charset="utf-8">
    <meta name="description" content="Free Web counter">
    <meta name="keywords" content="web counter, webconter, free web counter, own counter service script, own webcounter service script" />
    <meta name="author" content="ETI Free Stuff">
    <meta name="robots" content="all"/>
    <title>Free Web Counter</title>

    <link href="css/style.css" rel="stylesheet">

</head>

<body>

    <div id="top" class="header">
        <div class="vert-text">
            <h1>Free Web Counter <a href="./"><img src="img/counter.jpeg"></a></h1>
           
<center>

<h3>Under construction:)</h3>

</center>

<center><a href="http://eti.free.bg" target="_blank">ETI</a> 1998-<?php
echo date("Y") ;
?><br />
</center>
      
</body>
</html>
