Well, what to read:) do not read:) joke:) u must read many IT ebooks and practice...

This simple php script is free! NO license(licence) ... ... ...
Feel free to create own simple counter service:) to change the script, and what u want... :)

With this php script you can create own web counter service like -
example:
http://www.webcounter.com
http://www.hitwebcounter.com
http://www.freecountercode.com/counter-setup.php
and others...

Good luck!

If u want, u can visit my web pages: 

eti.free.bg - portfolio with some simple projects:)
brigante.sytes.net - many free IT Stuff there! free ebooks, tuts, videos...
e-down.hit.bg - free soft
to6ev.hit.bg - this is the way to express myself:)

...my nicknames: ETI, eti, brigante, hijackercracker, to6ev :)
