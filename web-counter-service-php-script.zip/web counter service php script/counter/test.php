<?php 
$random = substr(md5(rand()),0,7);
$file = fopen("./logs/$random.txt", "w+");

echo  '<textarea rows="7" cols="37" onclick="this.select()" readonly ><!-- Webcounter BEGIN CODE--><script language="Javascript" src="http://localhost/counter/counter.php?page='.$random.'"></script><!-- Webcounter END CODE--></textarea>' ;
?>
