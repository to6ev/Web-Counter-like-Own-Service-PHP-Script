<?php

// URL of the folder where script is installed. INCLUDE a trailing "/" !!!
$base_url = 'http://localhost/counter/';

// Default image style (font)
$default_style = 1;

// Default counter image extension
$default_ext = "png";

// Count "UNIQUE" visitors ONLY? 1 = YES, 0 = NO
// [well, unigue, but it's not so unique:) when the user clear browser history(Delete Private Data), then this counter 
// will count again:) javascript:)
// and we don't track IP address and do not log any IP's]
$count_unique = 1;

// Number of hours a visitor is considered as "unique"
$unique_hours = 24;

// Minimum number of digits shown (zero-padding). Set to 0 to disable.
$min_digits = 5;

/* Turn error notices off */
error_reporting(E_ALL ^ E_NOTICE);

/* Get page and log file names */
$page       = input($_GET['page']); //counter.php?page=1&style=1&digits=5
$logfile    = 'logs/' . $page . '.txt';

/* Get style and extension information */
$style      = input($_GET['style']) or $style = $default_style; //counter.php?page=1&style=1&digits=5
$style_dir  = 'styles/' . $style . '/';
$ext        = input($_GET['ext']) or $ext = $default_ext;
$digits     = input($_GET['digits']) or $digits = $min_digits; //counter.php?page=1&style=1&digits=5

/* This functin handles input parameters making sure nothing dangerous is passed in */
function input($in)
{
    $out = htmlentities(stripslashes($in));
    $out = str_replace(array('/','\\'), '', $out);
    return $out;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Free Web Counter</title>
    <LINK REL="SHORTCUT ICON" href="img/counter.jpeg">
    <meta charset="utf-8">
    <meta name="description" content="Free Web counter">
    <meta name="keywords" content="web counter, webconter, free web counter, own counter service script, own webcounter service script" />
    <meta name="author" content="ETI Free Stuff">
    <meta name="robots" content="all"/>
    <link href="css/style.css" rel="stylesheet">
</head>

<body>

    <div id="top" class="header">
    <div class="vert-text">
            <h1><a href="./">Free Web Counter <img src="img/counter.jpeg"></a></h1>
            <h2>
                <em>For</em> your website
            </h2>
<?php 
$random = substr(md5(rand()),0,10);
$file = fopen("./logs/$random.txt", "w+");
?>

<h3>Get the code</h3>
<small>Copy and paste the code of the page you want in your site. That's all!</small><br />

<?php 
echo  '<textarea style="color: white; background-color: transparent" rows="7" cols="37" onclick="this.select()" readonly ><!-- Webcounter BEGIN CODE-->
<script language="Javascript" src="http://localhost/counter/counter.php?page='.$random.'&style='.$style.'&digits='.$digits.'"></script>
<!-- Webcounter END CODE--></textarea>' ;
echo '<br>Preview:<br><script language="Javascript" src="http://localhost/counter/counter.php?page='.$random.'&style='.$style.'&digits='.$digits.'"></script>';
?>

<br><p>Choose how many digits and Get new counter:
<form action="">
<select name="digits">
<option value="1">1</option>
<option value="2">02</option>
<option value="3">003</option>
<option value="4">0004</option>
<option selected="selected" value="5">00005</option>
<option value="6">000006</option>
<option value="7">0000007</option>
<option value="8">00000008</option> 
<option value="9">000000009</option>
<option value="10">0000000010</option>
</select></p>
<!--
<input type="image" src="./img/spaceship.png" border="0" width="95" height="50" title="Greate new counter" alt="Get new counter" /><br><small>Get new code</small>
-->
 
<img src="./img/spaceship.png" border="0" width="95" height="50">
                                
<br />

<div id="choosecolorbg">    
<p>Select Counter model from our 209 Styles and click on UFO to get new code</p>
<br> 

<input onChange="submit();return false;" type="radio" name="style" value="1"><script language="Javascript" src="./counter.php?page=2&style=1&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="2"><script language="Javascript" src="./counter.php?page=2&style=2&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="3"><script language="Javascript" src="./counter.php?page=2&style=3&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="4"><script language="Javascript" src="./counter.php?page=2&style=4&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="5"><script language="Javascript" src="./counter.php?page=2&style=5&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="6"><script language="Javascript" src="./counter.php?page=2&style=6&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="7"><script language="Javascript" src="./counter.php?page=2&style=7&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="8"><script language="Javascript" src="./counter.php?page=2&style=8&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="9"><script language="Javascript" src="./counter.php?page=2&style=9&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="10"><script language="Javascript" src="./counter.php?page=2&style=10&digits=5"></script><br>
<input onChange="submit();return false;" type="radio" name="style" value="11"><script language="Javascript" src="./counter.php?page=2&style=11&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="12"><script language="Javascript" src="./counter.php?page=2&style=12&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="13"><script language="Javascript" src="./counter.php?page=2&style=13&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="14"><script language="Javascript" src="./counter.php?page=2&style=14&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="15"><script language="Javascript" src="./counter.php?page=2&style=15&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="16"><script language="Javascript" src="./counter.php?page=2&style=16&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="17"><script language="Javascript" src="./counter.php?page=2&style=17&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="18"><script language="Javascript" src="./counter.php?page=2&style=18&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="19"><script language="Javascript" src="./counter.php?page=2&style=19&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="20"><script language="Javascript" src="./counter.php?page=2&style=20&digits=5"></script><br>
<input onChange="submit();return false;" type="radio" name="style" value="21"><script language="Javascript" src="./counter.php?page=2&style=21&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="22"><script language="Javascript" src="./counter.php?page=2&style=22&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="23"><script language="Javascript" src="./counter.php?page=2&style=23&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="24"><script language="Javascript" src="./counter.php?page=2&style=24&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="25"><script language="Javascript" src="./counter.php?page=2&style=25&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="26"><script language="Javascript" src="./counter.php?page=2&style=26&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="27"><script language="Javascript" src="./counter.php?page=2&style=27&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="28"><script language="Javascript" src="./counter.php?page=2&style=28&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="29"><script language="Javascript" src="./counter.php?page=2&style=29&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="30"><script language="Javascript" src="./counter.php?page=2&style=30&digits=5"></script><br>
<input onChange="submit();return false;" type="radio" name="style" value="31"><script language="Javascript" src="./counter.php?page=2&style=31&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="32"><script language="Javascript" src="./counter.php?page=2&style=32&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="33"><script language="Javascript" src="./counter.php?page=2&style=33&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="34"><script language="Javascript" src="./counter.php?page=2&style=34&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="35"><script language="Javascript" src="./counter.php?page=2&style=35&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="36"><script language="Javascript" src="./counter.php?page=2&style=36&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="37"><script language="Javascript" src="./counter.php?page=2&style=37&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="38"><script language="Javascript" src="./counter.php?page=2&style=38&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="39"><script language="Javascript" src="./counter.php?page=2&style=39&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="40"><script language="Javascript" src="./counter.php?page=2&style=40&digits=5"></script><br>
<input onChange="submit();return false;" type="radio" name="style" value="41"><script language="Javascript" src="./counter.php?page=2&style=41&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="42"><script language="Javascript" src="./counter.php?page=2&style=42&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="43"><script language="Javascript" src="./counter.php?page=2&style=43&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="44"><script language="Javascript" src="./counter.php?page=2&style=44&digits=5"></script>

<input onChange="submit();return false;" type="radio" name="style" value="46"><script language="Javascript" src="./counter.php?page=2&style=46&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="47"><script language="Javascript" src="./counter.php?page=2&style=47&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="48"><script language="Javascript" src="./counter.php?page=2&style=48&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="49"><script language="Javascript" src="./counter.php?page=2&style=49&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="50"><script language="Javascript" src="./counter.php?page=2&style=50&digits=5"></script><br>
<input onChange="submit();return false;" type="radio" name="style" value="51"><script language="Javascript" src="./counter.php?page=2&style=51&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="52"><script language="Javascript" src="./counter.php?page=2&style=52&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="53"><script language="Javascript" src="./counter.php?page=2&style=53&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="54"><script language="Javascript" src="./counter.php?page=2&style=54&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="55"><script language="Javascript" src="./counter.php?page=2&style=55&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="56"><script language="Javascript" src="./counter.php?page=2&style=56&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="57"><script language="Javascript" src="./counter.php?page=2&style=57&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="58"><script language="Javascript" src="./counter.php?page=2&style=58&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="59"><script language="Javascript" src="./counter.php?page=2&style=59&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="60"><script language="Javascript" src="./counter.php?page=2&style=60&digits=5"></script><br>
<input onChange="submit();return false;" type="radio" name="style" value="61"><script language="Javascript" src="./counter.php?page=2&style=61&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="62"><script language="Javascript" src="./counter.php?page=2&style=62&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="63"><script language="Javascript" src="./counter.php?page=2&style=63&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="64"><script language="Javascript" src="./counter.php?page=2&style=64&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="65"><script language="Javascript" src="./counter.php?page=2&style=65&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="66"><script language="Javascript" src="./counter.php?page=2&style=66&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="67"><script language="Javascript" src="./counter.php?page=2&style=67&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="68"><script language="Javascript" src="./counter.php?page=2&style=68&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="69"><script language="Javascript" src="./counter.php?page=2&style=69&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="70"><script language="Javascript" src="./counter.php?page=2&style=70&digits=5"></script><br>
<input onChange="submit();return false;" type="radio" name="style" value="71"><script language="Javascript" src="./counter.php?page=2&style=71&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="72"><script language="Javascript" src="./counter.php?page=2&style=72&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="73"><script language="Javascript" src="./counter.php?page=2&style=73&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="74"><script language="Javascript" src="./counter.php?page=2&style=74&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="75"><script language="Javascript" src="./counter.php?page=2&style=75&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="76"><script language="Javascript" src="./counter.php?page=2&style=76&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="77"><script language="Javascript" src="./counter.php?page=2&style=77&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="78"><script language="Javascript" src="./counter.php?page=2&style=78&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="79"><script language="Javascript" src="./counter.php?page=2&style=79&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="80"><script language="Javascript" src="./counter.php?page=2&style=80&digits=5"></script><br>
<input onChange="submit();return false;" type="radio" name="style" value="81"><script language="Javascript" src="./counter.php?page=2&style=81&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="82"><script language="Javascript" src="./counter.php?page=2&style=82&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="83"><script language="Javascript" src="./counter.php?page=2&style=83&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="84"><script language="Javascript" src="./counter.php?page=2&style=84&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="85"><script language="Javascript" src="./counter.php?page=2&style=85&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="86"><script language="Javascript" src="./counter.php?page=2&style=86&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="87"><script language="Javascript" src="./counter.php?page=2&style=87&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="88"><script language="Javascript" src="./counter.php?page=2&style=88&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="89"><script language="Javascript" src="./counter.php?page=2&style=89&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="90"><script language="Javascript" src="./counter.php?page=2&style=90&digits=5"></script><br>
<input onChange="submit();return false;" type="radio" name="style" value="91"><script language="Javascript" src="./counter.php?page=2&style=91&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="92"><script language="Javascript" src="./counter.php?page=2&style=92&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="93"><script language="Javascript" src="./counter.php?page=2&style=93&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="94"><script language="Javascript" src="./counter.php?page=2&style=94&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="95"><script language="Javascript" src="./counter.php?page=2&style=95&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="96"><script language="Javascript" src="./counter.php?page=2&style=96&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="97"><script language="Javascript" src="./counter.php?page=2&style=97&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="98"><script language="Javascript" src="./counter.php?page=2&style=98&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="99"><script language="Javascript" src="./counter.php?page=2&style=99&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="100"><script language="Javascript" src="./counter.php?page=2&style=100&digits=5"></script><br>
<input onChange="submit();return false;" type="radio" name="style" value="101"><script language="Javascript" src="./counter.php?page=2&style=101&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="102"><script language="Javascript" src="./counter.php?page=2&style=102&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="103"><script language="Javascript" src="./counter.php?page=2&style=103&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="104"><script language="Javascript" src="./counter.php?page=2&style=104&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="105"><script language="Javascript" src="./counter.php?page=2&style=105&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="106"><script language="Javascript" src="./counter.php?page=2&style=106&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="107"><script language="Javascript" src="./counter.php?page=2&style=107&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="108"><script language="Javascript" src="./counter.php?page=2&style=108&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="109"><script language="Javascript" src="./counter.php?page=2&style=109&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="110"><script language="Javascript" src="./counter.php?page=2&style=110&digits=5"></script><br>
<input onChange="submit();return false;" type="radio" name="style" value="111"><script language="Javascript" src="./counter.php?page=2&style=111&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="112"><script language="Javascript" src="./counter.php?page=2&style=112&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="113"><script language="Javascript" src="./counter.php?page=2&style=113&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="114"><script language="Javascript" src="./counter.php?page=2&style=114&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="115"><script language="Javascript" src="./counter.php?page=2&style=115&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="116"><script language="Javascript" src="./counter.php?page=2&style=116&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="117"><script language="Javascript" src="./counter.php?page=2&style=117&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="118"><script language="Javascript" src="./counter.php?page=2&style=118&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="119"><script language="Javascript" src="./counter.php?page=2&style=119&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="120"><script language="Javascript" src="./counter.php?page=2&style=120&digits=5"></script><br>
<input onChange="submit();return false;" type="radio" name="style" value="121"><script language="Javascript" src="./counter.php?page=2&style=121&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="122"><script language="Javascript" src="./counter.php?page=2&style=122&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="123"><script language="Javascript" src="./counter.php?page=2&style=123&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="124"><script language="Javascript" src="./counter.php?page=2&style=124&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="125"><script language="Javascript" src="./counter.php?page=2&style=125&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="126"><script language="Javascript" src="./counter.php?page=2&style=126&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="127"><script language="Javascript" src="./counter.php?page=2&style=127&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="128"><script language="Javascript" src="./counter.php?page=2&style=128&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="129"><script language="Javascript" src="./counter.php?page=2&style=129&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="130"><script language="Javascript" src="./counter.php?page=2&style=130&digits=5"></script><br>
<input onChange="submit();return false;" type="radio" name="style" value="131"><script language="Javascript" src="./counter.php?page=2&style=131&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="132"><script language="Javascript" src="./counter.php?page=2&style=132&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="133"><script language="Javascript" src="./counter.php?page=2&style=133&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="134"><script language="Javascript" src="./counter.php?page=2&style=134&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="135"><script language="Javascript" src="./counter.php?page=2&style=135&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="136"><script language="Javascript" src="./counter.php?page=2&style=136&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="137"><script language="Javascript" src="./counter.php?page=2&style=137&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="138"><script language="Javascript" src="./counter.php?page=2&style=138&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="139"><script language="Javascript" src="./counter.php?page=2&style=139&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="140"><script language="Javascript" src="./counter.php?page=2&style=140&digits=5"></script><br>
<input onChange="submit();return false;" type="radio" name="style" value="141"><script language="Javascript" src="./counter.php?page=2&style=141&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="142"><script language="Javascript" src="./counter.php?page=2&style=142&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="143"><script language="Javascript" src="./counter.php?page=2&style=143&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="144"><script language="Javascript" src="./counter.php?page=2&style=144&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="145"><script language="Javascript" src="./counter.php?page=2&style=145&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="146"><script language="Javascript" src="./counter.php?page=2&style=146&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="147"><script language="Javascript" src="./counter.php?page=2&style=147&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="148"><script language="Javascript" src="./counter.php?page=2&style=148&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="149"><script language="Javascript" src="./counter.php?page=2&style=149&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="150"><script language="Javascript" src="./counter.php?page=2&style=150&digits=5"></script><br>
<input onChange="submit();return false;" type="radio" name="style" value="151"><script language="Javascript" src="./counter.php?page=2&style=151&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="152"><script language="Javascript" src="./counter.php?page=2&style=152&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="153"><script language="Javascript" src="./counter.php?page=2&style=153&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="154"><script language="Javascript" src="./counter.php?page=2&style=154&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="155"><script language="Javascript" src="./counter.php?page=2&style=155&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="156"><script language="Javascript" src="./counter.php?page=2&style=156&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="157"><script language="Javascript" src="./counter.php?page=2&style=157&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="158"><script language="Javascript" src="./counter.php?page=2&style=158&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="159"><script language="Javascript" src="./counter.php?page=2&style=159&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="160"><script language="Javascript" src="./counter.php?page=2&style=160&digits=5"></script><br>
<input onChange="submit();return false;" type="radio" name="style" value="161"><script language="Javascript" src="./counter.php?page=2&style=161&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="162"><script language="Javascript" src="./counter.php?page=2&style=162&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="163"><script language="Javascript" src="./counter.php?page=2&style=163&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="164"><script language="Javascript" src="./counter.php?page=2&style=164&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="165"><script language="Javascript" src="./counter.php?page=2&style=165&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="166"><script language="Javascript" src="./counter.php?page=2&style=166&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="167"><script language="Javascript" src="./counter.php?page=2&style=167&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="168"><script language="Javascript" src="./counter.php?page=2&style=168&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="169"><script language="Javascript" src="./counter.php?page=2&style=169&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="170"><script language="Javascript" src="./counter.php?page=2&style=170&digits=5"></script><br>
<input onChange="submit();return false;" type="radio" name="style" value="171"><script language="Javascript" src="./counter.php?page=2&style=171&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="172"><script language="Javascript" src="./counter.php?page=2&style=172&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="173"><script language="Javascript" src="./counter.php?page=2&style=173&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="174"><script language="Javascript" src="./counter.php?page=2&style=174&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="175"><script language="Javascript" src="./counter.php?page=2&style=175&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="176"><script language="Javascript" src="./counter.php?page=2&style=176&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="177"><script language="Javascript" src="./counter.php?page=2&style=177&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="178"><script language="Javascript" src="./counter.php?page=2&style=178&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="179"><script language="Javascript" src="./counter.php?page=2&style=179&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="180"><script language="Javascript" src="./counter.php?page=2&style=180&digits=5"></script><br>
<input onChange="submit();return false;" type="radio" name="style" value="181"><script language="Javascript" src="./counter.php?page=2&style=181&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="182"><script language="Javascript" src="./counter.php?page=2&style=182&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="183"><script language="Javascript" src="./counter.php?page=2&style=183&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="184"><script language="Javascript" src="./counter.php?page=2&style=184&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="185"><script language="Javascript" src="./counter.php?page=2&style=185&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="186"><script language="Javascript" src="./counter.php?page=2&style=186&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="187"><script language="Javascript" src="./counter.php?page=2&style=187&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="188"><script language="Javascript" src="./counter.php?page=2&style=188&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="189"><script language="Javascript" src="./counter.php?page=2&style=189&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="190"><script language="Javascript" src="./counter.php?page=2&style=190&digits=5"></script><br>
<input onChange="submit();return false;" type="radio" name="style" value="191"><script language="Javascript" src="./counter.php?page=2&style=191&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="192"><script language="Javascript" src="./counter.php?page=2&style=192&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="193"><script language="Javascript" src="./counter.php?page=2&style=193&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="194"><script language="Javascript" src="./counter.php?page=2&style=194&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="195"><script language="Javascript" src="./counter.php?page=2&style=195&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="196"><script language="Javascript" src="./counter.php?page=2&style=196&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="197"><script language="Javascript" src="./counter.php?page=2&style=197&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="198"><script language="Javascript" src="./counter.php?page=2&style=198&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="199"><script language="Javascript" src="./counter.php?page=2&style=199&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="200"><script language="Javascript" src="./counter.php?page=2&style=200&digits=5"></script><br>
<input onChange="submit();return false;" type="radio" name="style" value="201"><script language="Javascript" src="./counter.php?page=2&style=201&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="202"><script language="Javascript" src="./counter.php?page=2&style=202&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="203"><script language="Javascript" src="./counter.php?page=2&style=203&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="204"><script language="Javascript" src="./counter.php?page=2&style=204&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="205"><script language="Javascript" src="./counter.php?page=2&style=205&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="206"><script language="Javascript" src="./counter.php?page=2&style=206&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="207"><script language="Javascript" src="./counter.php?page=2&style=207&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="208"><script language="Javascript" src="./counter.php?page=2&style=208&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="209"><script language="Javascript" src="./counter.php?page=2&style=209&digits=5"></script>
<input onChange="submit();return false;" type="radio" name="style" value="210"><script language="Javascript" src="./counter.php?page=2&style=210&digits=5"></script>
</form>

<p>Background Color Preview - Move the mouse to the color you want to test</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>
        <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">

          <tr>
            <td><table border="1" width="0%" height="0%" bgcolor="#FFFFFF">
                <tr>
                  <td><a href="#" onmouseover="document.getElementById('choosecolorbg').style.backgroundColor='#FFFFFF'"><img src="" width="10" height="10" border="0" /></a></td>
                </tr>
            </table></td>
            <td><table border="1" width="0%" height="0%" bgcolor="#CC00CC">
                <tr>
                  <td><a href="#" onmouseover="document.getElementById('choosecolorbg').style.backgroundColor='#CC00CC'"><img src="" width="10" height="10" border="0" /></a></td>
                </tr>
            </table></td>
            <td><table border="1" width="0%" height="0%" bgcolor="pink">
                <tr>
                  <td><a href="#" onmouseover="document.getElementById('choosecolorbg').style.backgroundColor='pink'"><img src="" width="10" height="10" border="0" /></a></td>
                </tr>
            </table></td>
            <td><table border="1" width="0%" height="0%" bgcolor="#FFCCFF">
                <tr>
                  <td><a href="#" onmouseover="document.getElementById('choosecolorbg').style.backgroundColor='#FFCCFF'"><img src="" width="10" height="10" border="0" /></a></td>
                </tr>
            </table></td>
            <td><table border="1" width="0%" height="0%" bgcolor="#333333">
                <tr>
                  <td><a href="#" onmouseover="document.getElementById('choosecolorbg').style.backgroundColor='black'"><img src="" width="10" height="10" border="0" /></a></td>
                </tr>
            </table></td>
            <td><table border="1" width="0%" height="0%" bgcolor="#999999">
                <tr>
                  <td><a href="#" onmouseover="document.getElementById('choosecolorbg').style.backgroundColor='#999999'"><img src="" width="10" height="10" border="0" /></a></td>
                </tr>
            </table></td>
            <td><table border="1" width="0%" height="0%" bgcolor="#CCCCCC">
                <tr>
                  <td><a href="#" onmouseover="document.getElementById('choosecolorbg').style.backgroundColor='#CCCCCC'"><img src="" width="10" height="10" border="0" /></a></td>
                </tr>
            </table></td>
            <td><table border="1" width="0%" height="0%" bgcolor="#000099">
                <tr>
                  <td><a href="#" onmouseover="document.getElementById('choosecolorbg').style.backgroundColor='#000099'"><img src="" width="10" height="10" border="0" /></a></td>
                </tr>
            </table></td>
            <td><table border="1" width="0%" height="0%" bgcolor="#0000FF">
                <tr>
                  <td><a href="#" onmouseover="document.getElementById('choosecolorbg').style.backgroundColor='blue'"><img src="" width="10" height="10" border="0" /></a></td>
                </tr>
            </table></td>
            <td><table border="1" width="0%" height="0%" bgcolor="#E0FFFF">
                <tr>
                  <td><a href="#" onmouseover="document.getElementById('choosecolorbg').style.backgroundColor='#E0FFFF'"><img src="" width="10" height="10" border="0" /></a></td>
                </tr>
            </table></td>
            <td><table border="1" width="0%" height="0%" bgcolor="yellow">
                <tr>
                  <td><a href="#" onmouseover="document.getElementById('choosecolorbg').style.backgroundColor='yellow'"><img src="" width="10" height="10" border="0" /></a></td>
                </tr>
            </table></td>
            <td><table border="1" width="0%" height="0%" bgcolor="#FFFFCC">
                <tr>
                  <td><a href="#" onmouseover="document.getElementById('choosecolorbg').style.backgroundColor='#FFFFCC'"><img src="" width="10" height="10" border="0" /></a></td>
                </tr>
            </table></td>
            <td><table border="1" width="4" height="0%" bgcolor="#00FF66">
                <tr>
                  <td><a href="#" onmouseover="document.getElementById('choosecolorbg').style.backgroundColor='#00FF66'"><img src="" width="10" height="10" border="0" /></a></td>
                </tr>
            </table></td>
            <td><table border="1" width="0%" height="0%" bgcolor="green">
                <tr>
                  <td><a href="#" onmouseover="document.getElementById('choosecolorbg').style.backgroundColor='green'"><img src="" width="10" height="10" border="0" /></a></td>
                </tr>
            </table></td>
            <td><table border="1" width="0%" height="0%" bgcolor="#FF9900">
                <tr>
                  <td><a href="#" onmouseover="document.getElementById('choosecolorbg').style.backgroundColor='#FF9900'"><img src="" width="10" height="10" border="0" /></a></td>
                </tr>
            </table></td>
            <td><table border="1" width="0%" height="0%" bgcolor="#660000">
                <tr>
                  <td><a href="#" onmouseover="document.getElementById('choosecolorbg').style.backgroundColor='#660000'"><img src="" width="10" height="10" border="0" /></a></td>
                </tr>
            </table></td>
            <td><table border="1" width="0%" height="0%" bgcolor="#CC9999">
                <tr>
                  <td><a href="#" onmouseover="document.getElementById('choosecolorbg').style.backgroundColor='#CC9999'"><img src="" width="10" height="10" border="0" /></a></td>
                </tr>
            </table></td>
            <td><table border="1" width="0%" height="0%" bgcolor="#FF0000">
                <tr>
                  <td><a href="#" onmouseover="document.getElementById('choosecolorbg').style.backgroundColor='#FF0000'"><img src="" width="10" height="10" border="0" /></a></td>
                </tr>
            </table></td>

</div>
</body>
</html>
