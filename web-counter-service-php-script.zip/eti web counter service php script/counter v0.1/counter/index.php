<!DOCTYPE html>
<html lang="en">
<head>
<LINK REL="SHORTCUT ICON" href="img/counter.jpeg">
    <meta charset="utf-8">
    <meta name="description" content="Free Web counter">
    <meta name="keywords" content="web counter, webconter, free web counter, own counter service script, own webcounter service script" />
    <meta name="author" content="ETI Free Stuff">
    <meta name="robots" content="all"/>
    <title>Free Web Counter</title>

    <link href="css/style.css" rel="stylesheet">

</head>

<body>

    <div id="top" class="header">
        <div class="vert-text">
            <h1>Free Web Counter <a href="./"><img src="img/counter.jpeg"></a></h1>
            <h2>
                <em>For</em> your website
            </h2>
<small>Well, this is the counter:</small><br />
<!-- Webcounter BEGIN CODE-->
<script language="Javascript" src="http://localhost/counter/counter.php?page=1"></script>
<!-- Webcounter END CODE--><br />   
<small>Track da Universe:) Unique visits</small><br /> 
    
<center>

<h3>Get the code:</h3>
<p><small>Copy and paste the code of the page you want in your site. That's all!</small></p>

<?php 
$random = substr(md5(rand()),0,7);
$file = fopen("./logs/$random.txt", "w+");

echo  '<textarea style="color: white; background-color: transparent" rows="7" cols="37" onclick="this.select()" readonly ><!-- Webcounter BEGIN CODE-->
<script language="Javascript" src="http://localhost/counter/counter.php?page='.$random.'"></script>
<!-- Webcounter END CODE--></textarea>' ;
?>

</center>

<?php
$directory = "./logs/";
$filecount = 0;
$files = glob($directory . "*.txt");
if ($files){
$filecount = count($files);
}
echo "eti bot: $filecount web counters created...";
?>
<br />
<a href="./more-counters.php">More counters (soon as possible)</a><br />
<a href="http://brigante.sytes.net">Source code of this project</a>
      </div>
    </div>
    
<center><a href="http://eti.free.bg" target="_blank">ETI</a> 1998-<?php
echo date("Y") ;
?><br />
</center>
      
</body>
</html>
