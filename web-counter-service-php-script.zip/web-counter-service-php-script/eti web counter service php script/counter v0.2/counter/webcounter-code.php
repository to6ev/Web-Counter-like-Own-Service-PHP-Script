<?php

// URL of the folder where script is installed. INCLUDE a trailing "/"
$base_url = 'http://localhost/counter/';

// Default image style (font)
$default_style = "";

// Default counter image extension
$default_ext = "png";

// Count "UNIQUE" visitors ONLY? 1 = YES, 0 = NO
// [well, unigue, but it's not so unique:) when the user clear browser history(Delete Private Data), then this counter 
// will count again:) javascript:)
// and we don't track IP address and do not log any IP's]
$count_unique = 1;

// Number of hours a visitor is considered as "unique"
$unique_hours = 24;

// Minimum number of digits shown (zero-padding). Set to 0 to disable.
$min_digits = 5;

/* Turn error notices off */
error_reporting(E_ALL ^ E_NOTICE);

/* Get page and log file names */
$page       = input($_GET['page']); //counter.php?page=1&style=1&digits=5
$logfile    = 'logs/' . $page . '.txt';

/* Get style and extension information */
$style      = input($_GET['style']) or $style = $default_style; //counter.php?page=1&style=1&digits=5
$style_dir  = 'styles/' . $style . '/';
$ext        = input($_GET['ext']) or $ext = $default_ext;
$digits     = input($_GET['digits']) or $digits = $min_digits; //counter.php?page=1&style=1&digits=5

/* This functin handles input parameters making sure nothing dangerous is passed in */
function input($in)
{
    $out = htmlentities(stripslashes($in));
    $out = str_replace(array('/','\\'), '', $out);
    return $out;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<LINK REL="SHORTCUT ICON" href="img/counter.jpeg">
    <meta charset="utf-8">
    <meta name="description" content="Free Web counter">
    <meta name="keywords" content="web counter, free web counter, hit counter, hit counter script, webcounter, free web counter script, own counter service script, own webcounter service script, own web counter service, own web counter service script, php web counter service script, брояч за сайт, уеб брояч"/>
    <meta name="author" content="www.ETI.pw">
    <meta name="robots" content="all"/>
    <title>Free Web Counter</title>

    <link href="css/style.css" rel="stylesheet">
<script src="./dnl/display.php"></script>
</head>

<body>

    <div id="top" class="header">
    <div class="vert-text">
            <h1><a href="./">Free Web Counter <img src="img/counter.jpeg"></a></h1>
            <h2>
                <em>For</em> your website
            </h2>
<small>This is your counter</small><br />
<?php 
$random = substr(md5(rand()),0,10);
$file = fopen("./logs/$random.txt", "w+");

echo '<script language="Javascript" src="http://localhost/counter/counter.php?page='.$random.'&style=1&digits='.$digits.'"></script>';
?>
 
<center>

<h3>Get the code</h3>

<?php 
echo  '<textarea style="color: white; background-color: transparent" rows="7" cols="37" onclick="this.select()" readonly ><!-- Webcounter BEGIN CODE-->
<script language="Javascript" src="http://localhost/counter/counter.php?page='.$random.'&style=1&digits='.$digits.'"></script>
<!-- Webcounter END CODE--></textarea>' ;
?>

<br><p>Choose how many digits and Get new counter:
<form action="">
<select name="digits" onChange="submit();return false;">
<option value="1">1</option>
<option value="2">02</option>
<option value="3">003</option>
<option value="4">0004</option>
<option selected="selected" value="5">00005</option>
<option value="6">000006</option>
<option value="7">0000007</option>
<option value="8">00000008</option> 
<option value="9">000000009</option>
<option value="10">0000000010</option>
</select></p>
<input type="image" src="./img/spaceship.png" border="0" width="95" height="50" title="Greate new counter" alt="Get new counter" /><br><small>Get new code</small>
</form> 
                                           
<br />
<br><small>Copy and paste the code of the page you want in your site. That's all!</small>
<?php
$directory = "./logs/";
$filecount = 0;
$files = glob($directory . "*.txt");
if ($files){
$filecount = count($files);
}
echo "<br><small>eti bot: $filecount web counters created</small><br>";
?>
</center>
<br>
<a href="morecounters.php" title="More web counters" onclick="toggle_visibility('morecounters');"><h3>Choose other counter from our 209 styles</h3></a><br />

<script type="text/javascript">
    function toggle_visibility(id) {
 var e = document.getElementById(id);
 e.style.display = ((e.style.display!='none') ? 'none' : 'block');
 }
</script>

<br />
<div id="morecounters" style="display:none;">
Loading...<br>
<br />
</div>
<br>
<a href="./dnl/click.php?id=1" target="_blank">Source code of this project</a>
<script>ccount_unique('1')</script>
    </div>
    </div>
    
<center><a href="http://eti.bl.ee" target="_blank">ETI</a> 1998-<?php
echo date("Y") ;
?><br />
</center>
      
</body>
</html>
