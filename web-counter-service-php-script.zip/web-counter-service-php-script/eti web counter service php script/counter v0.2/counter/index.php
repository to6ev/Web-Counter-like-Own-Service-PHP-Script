<!DOCTYPE html>
<html lang="en">
<head>
<LINK REL="SHORTCUT ICON" href="img/counter.jpeg">
<meta charset="utf-8">
<meta name="description" content="Free Web counter">
<meta name="keywords" content="web counter, free web counter, hit counter, hit counter script, webcounter, free web counter script, own counter service script, own webcounter service script, own web counter service, own web counter service script, php web counter service script, брояч за сайт, уеб брояч"/>
<meta name="author" content="www.ETI.pw">
<meta name="robots" content="all"/>
<title>Free Web Counter</title>

<link href="css/style.css" rel="stylesheet">
<script src="./dnl/display.php"></script>
</head>



<body>

    <div id="top" class="header">
    <div class="vert-text">
            <h1><a href="./">Free Web Counter <img src="img/counter.jpeg"></a></h1>
            <h2>
                <em>For</em> your website
            </h2>
<small>This is the base counter</small><br />
<?php
echo '<script language="Javascript" src="http://localhost/counter/counter.php?page=1&style=1&digits=5"></script>';
?>
<br />   
<small>Track da Universe:) 'Unique' visits</small><br /> 
<br>
<center>
<a href="./webcounter-code.php"><img src="./img/spaceship.png" width="95" height="50" title="Create counter" alt="Create web counter" width="48" height="48"><br /><small>Get your counter code</small>
</center>
<br>
<a href="./morecounters.php" title="More web counters" onclick="toggle_visibility('morecounters');"><h3>Choose other counter from our 209 styles</h3></a><br />

<script type="text/javascript">
    function toggle_visibility(id) {
 var e = document.getElementById(id);
 e.style.display = ((e.style.display!='none') ? 'none' : 'block');
 }
</script>

<br />
<div id="morecounters" style="display:none;">
Loading...<br>
<br />
</div>
<br>
<a href="./dnl/click.php?id=1" target="_blank">Source code of this project</a>
<script>ccount_unique('1')</script>
    </div>
    </div>
    
<center><a href="http://eti.free.bg" target="_blank">ETI</a> 1998-<?php
echo date("Y") ;
?><br />
</center>
      
</body>
</html>
