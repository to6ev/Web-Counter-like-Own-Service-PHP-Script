This is version 0.2

put directory /counter/ into dir /www/ on your webserver

give write permissions of directory /logs/

when u host this script on a remote host, just change 'localhost' in index.php, counter.php, morecounters.php, webcounter-code.php with your domain and don't change it when u test on your pc :)

in directory /logs/ there are .txt files
they are generated:) no data base(db) like MySQL :)
this simple script use .txt files to track, count ...

u can choose different styles for da counter, and to create subpages with other counters 


This simple php script is free! NO license(licence) ... ... ...
Feel free to create own simple counter service, to change the script, and what u want.

With this php script you can create own web counter service like:
http://www.webcounter.com
http://www.hitwebcounter.com
http://www.freecountercode.com/counter-setup.php
http://smallcounter.com
and others...

Good luck!

If u want, u can visit my web page: www.eti.pw
